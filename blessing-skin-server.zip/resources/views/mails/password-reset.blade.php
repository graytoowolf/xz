<p>{!! trans('auth.forgot.mail.message', ['sitename' => option_localized('site_name')]) !!}</p>
<p>{!! trans('auth.forgot.mail.reset', ['url' => $url]) !!}</p>
<p>{!! trans('auth.forgot.mail.ignore') !!}</p>
