<?php

namespace App\Models;

use App\Models;
use DateTimeInterface;
use Illuminate\Database\Eloquent\Model;

class uuid extends Model
{
    protected $table = 'uuid';
}
