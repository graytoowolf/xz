// // 删除下界门
// LevelEvents.tick(event => {
//     event.server.runCommandSilent('execute in minecraft:overworld run fill ~-15 ~-15 ~-15 ~15 ~15 ~15 air replace minecraft:nether_portal')
// })

