<?php

use Blessing\Filter;
use Illuminate\Contracts\Events\Dispatcher;
use Illuminate\Support\Collection;

return function (Dispatcher $events, Filter $filter) {
    $events->listen(
        'SocialiteProviders\Manager\SocialiteWasCalled',
        'SocialiteProviders\\Steam\\SteamExtendSocialite@handle'
    );

    config(['services.steam' => [
        'client_id' => null,
        'client_secret' => null,
        'redirect' => env('APP_URL').'auth/steam/callback',
	'api_key' => env('STEAM_API_KEY'),
    ]]);

    $filter->add('oauth_providers', function (Collection $providers) {
        $providers->put('Steam', [
            'icon' => 'Steam',
            'displayName' => 'Steam',
        ]);

        return $providers;
    });
};
